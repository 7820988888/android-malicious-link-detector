package com.example.maliciousurldetector;

public class AlarmDialogActivity {
}
