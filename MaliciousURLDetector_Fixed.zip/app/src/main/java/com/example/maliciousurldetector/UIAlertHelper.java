package com.example.maliciousurldetector;

public class UIAlertHelper {
}
