package com.example.maliciousurldetector;

public class AlertActivity {
}
