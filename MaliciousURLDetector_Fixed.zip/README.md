# Android-Application-Malicous-URL-Detector
Android-Application-Malicous-URL-Detector

## How to install

Note : If "App not installed application" error encountered the turn off Google Play Protect.

1. Open APK file.

      ![How to install](/Images/img1.jpg)

2. The installation will begin.

      ![How to install](/Images/img2.jpg)

3. Open the Android Appication.

      ![How to install](/Images/img3.jpg)
    
4. In navigation bar various options are available such as to open the database where search history is recorded.

      ![How to install](/Images/img4.jpg)
    
## Test the Android Application

1. If a Malicious URL is entered details like City, Organisation, Address, Zipcode, Country, Emails, Domain and Alexa Rank will be displayed along with a warning. 

      ![How to install](/Images/img5.jpg)
  
      ![How to install](/Images/img6.jpg)

2. If a Legitimate URL is entered details like City, Organisation, Address, Zipcode, Country, Emails, Domain and Alexa Rank will be displayed without a warning. 

      ![How to install](/Images/img7.jpg)
    
      ![How to install](/Images/img8.jpg)
    
